# Visuels promotionnels ZAPIKI — 10 langues

Ces images sont des compositions promotionnelles, non des captures d’écran brutes de l’application.
Chaque langue possède sept visuels, selon l’ordre : Accueil, Direct, Catégories, Films, Séries, Favoris, Réglages.
La langue japonaise provient du dossier `jp`; le coréen du dossier `kr`.

Format optimisé WebP, 820 pixels de large maximum. Ne jamais recadrer ni déformer.

## Correspondance

- `fr/01.webp` ← `fr/Image ChatGPT 26 oct. 2026, 11_19_06-1.png`, 820×1457, 128854 octets, SHA256 `6154a5209377e9df5fd004082303e29787398fe7f82efbc89da64a2535801323`
- `fr/02.webp` ← `fr/Image ChatGPT 26 oct. 2026, 11_19_07-2.png`, 820×1457, 92348 octets, SHA256 `d33c22be2fa15c29dfdbdca381cc8594bef01cf40c7f9d53f658c805f650a6f6`
- `fr/03.webp` ← `fr/Image ChatGPT 26 oct. 2026, 11_19_08-3.png`, 820×1457, 86904 octets, SHA256 `a485e20a70be5a78092a2723c25c5892715a0beed6a3c21d4a4ecbed1cf98461`
- `fr/04.webp` ← `fr/Image ChatGPT 26 oct. 2026, 11_19_08-4.png`, 820×1457, 126984 octets, SHA256 `0be2064c0ad5b8465ddcc3c801212e7bf2af09962b22847912257c529d7bdada`
- `fr/05.webp` ← `fr/Image ChatGPT 26 oct. 2026, 11_19_09-5.png`, 820×1457, 119242 octets, SHA256 `7045090a55e1ec59f8e1a3b0e2fcc8d28b6f6888807f0b15546f132d7d5d4ffd`
- `fr/06.webp` ← `fr/Image ChatGPT 26 oct. 2026, 11_19_09-6.png`, 820×1457, 89966 octets, SHA256 `b6072841b10ca028c310b9980e6ec6858c841a42695e13fe671ec19a75185433`
- `fr/07.webp` ← `fr/Image ChatGPT 26 oct. 2026, 11_19_10-7.png`, 820×1457, 83020 octets, SHA256 `7c92771983710db9488a31476a6da1fac9b0c709a6ff1602adb5884298bc9017`
- `en/01.webp` ← `en/Image ChatGPT 26 oct. 2026, 19_24_24-1.png`, 820×1457, 128236 octets, SHA256 `981ab8dfdddc956814023a3aaa9e93ea76f68d901fde621a0637579d6823d064`
- `en/02.webp` ← `en/Image ChatGPT 26 oct. 2026, 19_24_25-2.png`, 820×1457, 87492 octets, SHA256 `d2eb4dd8c87be9eadbf7019c465459fa43648c95847438e656e55e9b2519ce93`
- `en/03.webp` ← `en/Image ChatGPT 26 oct. 2026, 19_24_26-3.png`, 820×1457, 83886 octets, SHA256 `a2a5863336d22ddcafd0c46aeccd921470c062da6e242227665f631b82dce4f6`
- `en/04.webp` ← `en/Image ChatGPT 26 oct. 2026, 19_24_26-4.png`, 820×1457, 124332 octets, SHA256 `cd53ce7c7712cefd4c061b8ff56f927f7f79b1d83139e42c826b90e91dca75f4`
- `en/05.webp` ← `en/Image ChatGPT 26 oct. 2026, 19_24_27-5.png`, 820×1457, 106908 octets, SHA256 `7abec9da02dfddbe9ef84404dfdcb8b239044d1b5bb0dc45c40501cdae63b70b`
- `en/06.webp` ← `en/Image ChatGPT 26 oct. 2026, 19_24_29-6.png`, 820×1457, 90634 octets, SHA256 `5312620d27ec8abc3f71559cd43a65fe0e3411f381bcb786e912596ecb48616b`
- `en/07.webp` ← `en/Image ChatGPT 26 oct. 2026, 19_24_30-7.png`, 820×1457, 82432 octets, SHA256 `4ef67aa02d30d8adb8a54b65bf8650cba25bc6a4012731a6d9c921a61a561141`
- `es/01.webp` ← `es/Image ChatGPT 26 oct. 2026, 19_28_52-1.png`, 820×1457, 132928 octets, SHA256 `e09c8a3504a62b493ea865e529e33b2d844644bfe1b7a29147c033fcd840995a`
- `es/02.webp` ← `es/Image ChatGPT 26 oct. 2026, 19_28_53-2.png`, 820×1457, 95934 octets, SHA256 `a8b4f3206875de4fc027dd52e728cd23f1e5549a8b6c823929705efe72ed2cf8`
- `es/03.webp` ← `es/Image ChatGPT 26 oct. 2026, 19_28_54-3.png`, 820×1457, 88116 octets, SHA256 `fc3965332adfcd1d6e61a44df5e4130ba9e516552c8a9da26f9c5f9a854b4365`
- `es/04.webp` ← `es/Image ChatGPT 26 oct. 2026, 19_28_54-4.png`, 820×1457, 127082 octets, SHA256 `e19ef103f9436b1acb2d3ab370f26029d5296619f9a7f65bb36d2cb737b7eea5`
- `es/05.webp` ← `es/Image ChatGPT 26 oct. 2026, 19_29_09-1.png`, 820×1457, 120070 octets, SHA256 `252909023359b526c14e24ecfe96c5779a5d4ec9e7c1fd76eddfb8a422de10ef`
- `es/06.webp` ← `es/Image ChatGPT 26 oct. 2026, 19_29_10-2.png`, 820×1457, 93572 octets, SHA256 `27a4872bbd660a3cc6674d2e3f197f801dd5577a3fa4ac1533de5304981a977b`
- `es/07.webp` ← `es/Image ChatGPT 26 oct. 2026, 19_29_11-3.png`, 820×1457, 88610 octets, SHA256 `39b6a984503c5ebcca515f59fe1bd8f68aa3e4fc708671b221c9ce3ebd7c12f4`
- `it/01.webp` ← `it/Image ChatGPT 26 oct. 2026, 19_27_16.png`, 820×1457, 129612 octets, SHA256 `3497d7e3821e5e651630622e9d39e9b98303fe188f34c4586697a3b5c88b7bbe`
- `it/02.webp` ← `it/Image ChatGPT 26 oct. 2026, 19_27_33-2.png`, 820×1457, 92568 octets, SHA256 `e21b32d03c0daef70ad7bbd85694addb12046121de59dc93b6c4082251df6eeb`
- `it/03.webp` ← `it/Image ChatGPT 26 oct. 2026, 19_27_35-3.png`, 820×1457, 87976 octets, SHA256 `6ffacf5bd84fb99a2fda06a5898c880a400a667e887ec17afd3289403c308f0d`
- `it/04.webp` ← `it/Image ChatGPT 26 oct. 2026, 19_27_35-4.png`, 820×1457, 122650 octets, SHA256 `1d05488c7e27f1d2b774ed073376a46d10d7f86288044d0cb1374a1bec619da7`
- `it/05.webp` ← `it/Image ChatGPT 26 oct. 2026, 19_27_36-5.png`, 820×1457, 107622 octets, SHA256 `86fd0a63dca9aadf1ad35c959f203b152a72b0087984b60eeeb52eaa622dcb6d`
- `it/06.webp` ← `it/Image ChatGPT 26 oct. 2026, 19_27_37-6.png`, 820×1457, 90006 octets, SHA256 `4c77b5b385ceef8075e6478147321703c3eb241387b354c0be12078202c5450f`
- `it/07.webp` ← `it/Image ChatGPT 26 oct. 2026, 19_27_39-7.png`, 820×1457, 88920 octets, SHA256 `d3a9bc3e6727c083ecc87843c4b956fb9cbde18d9c5287f4eb43b1ee1db25d33`
- `de/01.webp` ← `de/Image ChatGPT 26 oct. 2026, 19_25_53-1.png`, 820×1457, 126544 octets, SHA256 `1387751895c94e54f4f4276f33e66fde66922452c0bf8a43abf383f315f2fd92`
- `de/02.webp` ← `de/Image ChatGPT 26 oct. 2026, 19_25_54-2.png`, 820×1457, 95224 octets, SHA256 `c8ab1c1e8514a0df58e7bc0eb6fde5746b97ace36658791a27d87aa14642f171`
- `de/03.webp` ← `de/Image ChatGPT 26 oct. 2026, 19_25_57-3.png`, 820×1457, 90340 octets, SHA256 `3d24fb6a2bd074056dba0cdc78ef69530af753fab9aae1896c52603cee9715c7`
- `de/04.webp` ← `de/Image ChatGPT 26 oct. 2026, 19_25_57-4.png`, 820×1457, 128032 octets, SHA256 `589f3bdaf375bb91d590fdf2f695397779856ce931d028e598eb40c6468937cb`
- `de/05.webp` ← `de/Image ChatGPT 26 oct. 2026, 19_25_59-5.png`, 820×1457, 118368 octets, SHA256 `a2bbbb51967786f0d09eedf51014cb56b75ce7fad7d2b409c053ace6e2406604`
- `de/06.webp` ← `de/Image ChatGPT 26 oct. 2026, 19_25_59-6.png`, 820×1457, 90982 octets, SHA256 `2bd5e50103ebd2b29b314a5e277430bb432c3ca699a1bf169b82b5567ebc0106`
- `de/07.webp` ← `de/Image ChatGPT 26 oct. 2026, 19_26_00-7.png`, 820×1457, 85884 octets, SHA256 `9b8b4aa5dab14218700f53afb3fa4c4d9138a318ac43e397b3ba7cf173818832`
- `nl/01.webp` ← `nl/Image ChatGPT 26 oct. 2026, 19_31_43-1.png`, 820×1457, 126924 octets, SHA256 `568afeee15ce59930d383949c7c182c06d79da3f663ed2c006dcfa2a81c760cd`
- `nl/02.webp` ← `nl/Image ChatGPT 26 oct. 2026, 19_31_44-2.png`, 820×1457, 92648 octets, SHA256 `7e5b70742768261bb06669fa246b29c1503660ab1083a91a4089847c47a7ff0e`
- `nl/03.webp` ← `nl/Image ChatGPT 26 oct. 2026, 19_31_44-3.png`, 820×1457, 88750 octets, SHA256 `5598497ae953e862baecec7d757604ea87f35a4488692e5d31c7b9a749196118`
- `nl/04.webp` ← `nl/Image ChatGPT 26 oct. 2026, 19_31_45-4.png`, 820×1457, 124862 octets, SHA256 `9df272c3b3f1afc1c960451180d3c64aee97e0a2a5efc49033a7a40f02e57240`
- `nl/05.webp` ← `nl/Image ChatGPT 26 oct. 2026, 19_31_59-1.png`, 820×1457, 126940 octets, SHA256 `1a374bf102d7c08709b8ea80ef853187ad252e834774e24cc375c1a2013067ff`
- `nl/06.webp` ← `nl/Image ChatGPT 26 oct. 2026, 19_32_00-2.png`, 820×1457, 91512 octets, SHA256 `5a7143701b272fceb84f2eaff048258c5bc64337cdb2bcb3e37fd5875675938d`
- `nl/07.webp` ← `nl/Image ChatGPT 26 oct. 2026, 19_32_01-3.png`, 820×1457, 91246 octets, SHA256 `b9af020fc638221c0de5f59041c75e02fb461fc39944c9bdeee37a05ac254dbb`
- `pt/01.webp` ← `pt/ZAPIKI_PT_Visuel_1.png`, 820×1456, 120264 octets, SHA256 `da141819f3e980f31b2d548490e5f03b9aacdf729896632672537d0eb62b9c8b`
- `pt/02.webp` ← `pt/ZAPIKI_PT_Visuel_2.png`, 820×1456, 90642 octets, SHA256 `bbebf3f374661853702140d04a6454c1ad80430c234845122c980fb5b1403066`
- `pt/03.webp` ← `pt/ZAPIKI_PT_Visuel_3.png`, 820×1456, 84422 octets, SHA256 `02d07682d3766b275a3d4c87d9a5e4186b64288dbc0ba6f635a28995ee33934f`
- `pt/04.webp` ← `pt/ZAPIKI_PT_Visuel_4.png`, 820×1456, 116988 octets, SHA256 `3561dbcf6ebc584bb7129160da9f59d1025bf684b35073eac2e136c3c1fab9f9`
- `pt/05.webp` ← `pt/Image ChatGPT 26 oct. 2026, 19_59_53-1.png`, 820×1457, 170764 octets, SHA256 `528adbefea91ab27a3c86c3060beff20722a57f4fb994cdb2e461cee34a2139d`
- `pt/06.webp` ← `pt/Image ChatGPT 26 oct. 2026, 19_59_54-2.png`, 820×1457, 137102 octets, SHA256 `e96f1a3588fe055a085a0f25816087b0ee938519e50bb0e359a1f52346e6da47`
- `pt/07.webp` ← `pt/Image ChatGPT 26 oct. 2026, 19_59_55-3.png`, 820×1457, 130068 octets, SHA256 `88be9003f7ca1d6acf616f2da4d8de462181799dfb96a175d5cb483a751eb756`
- `ar/01.webp` ← `ar/Image ChatGPT 26 oct. 2026, 19_30_03-1.png`, 820×1457, 122882 octets, SHA256 `7eb7421b6d12180148a137a6e78169669b8d0b137cf692bace24b5c3a30b5a46`
- `ar/02.webp` ← `ar/Image ChatGPT 26 oct. 2026, 19_30_04-2.png`, 820×1457, 85902 octets, SHA256 `1e2c39eb0dc3abcd1cbce439c05a94ff07c4e4ef9dc550e6ae92ece370acf210`
- `ar/03.webp` ← `ar/Image ChatGPT 26 oct. 2026, 19_30_04-3.png`, 820×1457, 77998 octets, SHA256 `dc89de5f166fd76f48a3276e7e386c67a13be07b74f9e6c84fbe69c8b2c80710`
- `ar/04.webp` ← `ar/Image ChatGPT 26 oct. 2026, 19_30_05-4.png`, 820×1457, 124784 octets, SHA256 `a350a02fe67f55eefd651b77f31a74c742cdbc0415530dc023c1fa1de4ec9abc`
- `ar/05.webp` ← `ar/Image ChatGPT 26 oct. 2026, 19_30_35-1.png`, 820×1457, 117014 octets, SHA256 `40c580e0e61cfc05639dbdc440d9641ae548c513bbc9fe681f8460d9ad127045`
- `ar/06.webp` ← `ar/Image ChatGPT 26 oct. 2026, 19_30_36-2.png`, 820×1457, 82470 octets, SHA256 `aaf8cf73bcdbe8975e58c59fa80923dbd6fcb02fa2fa6646756895da08145c44`
- `ar/07.webp` ← `ar/Image ChatGPT 26 oct. 2026, 19_30_37-3.png`, 820×1457, 82096 octets, SHA256 `b00370d8f15144ded02d167ea4ecdb8660bee7bd2f68dbc863ea2cb98c0d35e4`
- `ja/01.webp` ← `jp/Image ChatGPT 26 oct. 2026, 20_26_34-1.png`, 820×1457, 131178 octets, SHA256 `e11ee68656950dcb2fb374f9b9725c75a3747ad37ae3a473674eace633d31e93`
- `ja/02.webp` ← `jp/Image ChatGPT 26 oct. 2026, 20_26_34-2.png`, 820×1457, 96032 octets, SHA256 `0711482bf6d1cb1af613dca923e229c8573388f939d66fbcd0495830102f73ea`
- `ja/03.webp` ← `jp/Image ChatGPT 26 oct. 2026, 20_26_35-3.png`, 820×1457, 86670 octets, SHA256 `51c565e3cd2368bc10c90210cf2f37724704e7298869b2cd905f306c551156e5`
- `ja/04.webp` ← `jp/Image ChatGPT 26 oct. 2026, 20_26_36-4.png`, 820×1457, 119662 octets, SHA256 `87709816fc58903532ee5c9308501ca90daea6773dd801664ff0c04679187813`
- `ja/05.webp` ← `jp/Image ChatGPT 26 oct. 2026, 20_29_39-1.png`, 820×1457, 119342 octets, SHA256 `02f9473126d587bd785a603aef1583f515e4d7af3d28c449beed31d08ef76635`
- `ja/06.webp` ← `jp/Image ChatGPT 26 oct. 2026, 20_29_40-2.png`, 820×1457, 93496 octets, SHA256 `b4977dc1fcf3bddd6a53aaae1015fa6310109ffec7b4f3ac795185ae6dea6e8d`
- `ja/07.webp` ← `jp/Image ChatGPT 26 oct. 2026, 20_29_41-3.png`, 820×1457, 83228 octets, SHA256 `c990f636ed07d105e7244dd6eef1397715896410c006defd7bf5ba2cdb697bbc`
- `ko/01.webp` ← `kr/Image ChatGPT 26 oct. 2026, 20_14_04-1.png`, 820×1457, 123856 octets, SHA256 `4fcf170ee6bd21ed6683fb59f4ed2912b338f52a7e2efdfa029a6837f65264d9`
- `ko/02.webp` ← `kr/Image ChatGPT 26 oct. 2026, 20_14_05-2.png`, 820×1457, 87942 octets, SHA256 `ada631ad515d798dcbd85c648dbf3d491ae51cc03951ceabdcdfe3323f0f0202`
- `ko/03.webp` ← `kr/Image ChatGPT 26 oct. 2026, 20_14_06-3.png`, 820×1457, 85050 octets, SHA256 `d5a201d0a9b3f959dcc1b1d71a58abae88e60a2b957fc14298f35ae4c753df68`
- `ko/04.webp` ← `kr/Image ChatGPT 26 oct. 2026, 20_14_07-4.png`, 820×1457, 123132 octets, SHA256 `e5e48537fb1250ab866d6e6c3bf79b72b751bbbdb1336b191e8c22fb7e2e6c45`
- `ko/05.webp` ← `kr/Image ChatGPT 26 oct. 2026, 20_14_19-1.png`, 820×1457, 119292 octets, SHA256 `a9375a5e4f2e0647ad35001192a754b620c245177749bea39a52bc4d3ef76961`
- `ko/06.webp` ← `kr/Image ChatGPT 26 oct. 2026, 20_14_20-2.png`, 820×1457, 87532 octets, SHA256 `6ed163f05e5ed3977f4bdd1e896b12f43579a6416e0e3be066dd09acce01ed95`
- `ko/07.webp` ← `kr/Image ChatGPT 26 oct. 2026, 20_14_21-3.png`, 820×1457, 79278 octets, SHA256 `6abf39f88761b66efb12e36d8d8dd8138af95565a7a104608c8d77161f23dfba`
- `cinema.webp` ← `Soirée cinéma avec Zapiki.png`, 1024×500, 79844 octets, SHA256 `6d0ed9e97439ce85659e71697d9d43e776c8b178a6dc608e817edda23f4eec55`
- `icone-source.webp` ← `ZAPIKI_icone_512x512.png`, 512×512, 8716 octets, SHA256 `2c0e73b88be1e893e1c083cb8d2bd035c922696ebf1fb0e202e20a6298e066b4`
